export type PageName = 'home' | 'centers' | 'center-details' | 'courses' | 'contact';

export interface NavigationState {
  currentPage: PageName;
  selectedCenterId?: string;
}

export interface NavigationContextType {
  currentPage: PageName;
  navigate: (page: PageName, centerId?: string) => void;
  selectedCenterId?: string;
}