import React, { useState } from 'react';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardHeader } from '../components/ui/card';
import { Input } from '../components/ui/input';
import { Textarea } from '../components/ui/textarea';
import { Label } from '../components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { PageName } from '../types/navigation';
import { Phone, Mail, MapPin, Clock, Send, MessageCircle, HelpCircle, Users } from 'lucide-react';

interface ContactPageProps {
  onNavigate: (page: PageName) => void;
}

export function ContactPage({ onNavigate }: ContactPageProps) {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    subject: '',
    message: '',
    inquiryType: ''
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Simulate form submission
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    setIsSubmitting(false);
    setIsSubmitted(true);
  };

  const contactInfo = [
    {
      icon: Phone,
      title: 'الهاتف',
      details: ['+966 11 123 4567', '+966 50 987 6543'],
      description: 'متاح يومياً من 8:00 ص إلى 10:00 م'
    },
    {
      icon: Mail,
      title: 'البريد الإلكتروني',
      details: ['info@quran-centers.sa', 'support@quran-centers.sa'],
      description: 'نرد على جميع الرسائل خلال 24 ساعة'
    },
    {
      icon: MapPin,
      title: 'العنوان',
      details: ['طريق الملك فهد، حي العليا', 'الرياض 12211، المملكة العربية السعودية'],
      description: 'مقر الإدارة الرئيسي'
    },
    {
      icon: Clock,
      title: 'ساعات العمل',
      details: ['السبت - الخميس: 8:00 ص - 6:00 م', 'الجمعة: مغلق'],
      description: 'خدمة العملاء متاحة طوال أيام الأسبوع'
    }
  ];

  const faqItems = [
    {
      question: 'كيف يمكنني التسجيل في إحدى الدورات؟',
      answer: 'يمكنك التسجيل من خلال التواصل مباشرة مع المركز المطلوب أو ملء نموذج الاستفسار وسنتواصل معك.'
    },
    {
      question: 'هل جميع المراكز معتمدة؟',
      answer: 'نعم، جميع المراكز المدرجة في منصتنا حاصلة على التراخيص اللازمة ومعتمدة من الجهات المختصة.'
    },
    {
      question: 'هل يمكن تغيير الدورة بعد التسجيل؟',
      answer: 'نعم، يمكن تغيير الدورة حسب سياسة كل مركز. ننصح بالتواصل مع المركز لمعرفة التفاصيل.'
    },
    {
      question: 'هل توجد دورات عبر الإنترنت؟',
      answer: 'نعم، العديد من المراكز تقدم دورات عبر الإنترنت. يمكنك البحث عن الدورات الافتراضية من خلال الفلاتر.'
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Page Header */}
      <section className="bg-primary text-primary-foreground py-12">
        <div className="container mx-auto px-4">
          <div className="text-center space-y-4">
            <div className="flex justify-center items-center gap-3 mb-4">
              <MessageCircle className="w-8 h-8" />
              <h1 className="text-4xl">اتصل بنا</h1>
            </div>
            <p className="text-lg text-primary-foreground/90 max-w-2xl mx-auto">
              نحن هنا لمساعدتك في العثور على أفضل المراكز والدورات القرآنية. لا تتردد في التواصل معنا
            </p>
          </div>
        </div>
      </section>

      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Contact Form */}
          <div>
            <Card>
              <CardHeader>
                <h2 className="flex items-center gap-2">
                  <Send className="w-5 h-5" />
                  أرسل لنا رسالة
                </h2>
                <p className="text-muted-foreground">
                  {isSubmitted 
                    ? 'شكراً لك! تم إرسال رسالتك بنجاح وسنتواصل معك قريباً.'
                    : 'املأ النموذج أدناه وسنتواصل معك في أقرب وقت ممكن'
                  }
                </p>
              </CardHeader>
              
              {!isSubmitted ? (
                <CardContent>
                  <form onSubmit={handleSubmit} className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="name">الاسم الكامل *</Label>
                        <Input
                          id="name"
                          type="text"
                          value={formData.name}
                          onChange={(e) => handleInputChange('name', e.target.value)}
                          placeholder="أدخل اسمك الكامل"
                          required
                        />
                      </div>
                      
                      <div>
                        <Label htmlFor="email">البريد الإلكتروني *</Label>
                        <Input
                          id="email"
                          type="email"
                          value={formData.email}
                          onChange={(e) => handleInputChange('email', e.target.value)}
                          placeholder="example@email.com"
                          required
                        />
                      </div>
                    </div>
                    
                    <div>
                      <Label htmlFor="phone">رقم الهاتف</Label>
                      <Input
                        id="phone"
                        type="tel"
                        value={formData.phone}
                        onChange={(e) => handleInputChange('phone', e.target.value)}
                        placeholder="+966 50 123 4567"
                      />
                    </div>
                    
                    <div>
                      <Label htmlFor="inquiryType">نوع الاستفسار</Label>
                      <Select value={formData.inquiryType} onValueChange={(value) => handleInputChange('inquiryType', value)}>
                        <SelectTrigger>
                          <SelectValue placeholder="اختر نوع الاستفسار" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="registration">التسجيل في دورة</SelectItem>
                          <SelectItem value="center-info">معلومات عن المراكز</SelectItem>
                          <SelectItem value="technical">مشكلة تقنية</SelectItem>
                          <SelectItem value="suggestion">اقتراح أو شكوى</SelectItem>
                          <SelectItem value="partnership">شراكة</SelectItem>
                          <SelectItem value="other">أخرى</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div>
                      <Label htmlFor="subject">موضوع الرسالة *</Label>
                      <Input
                        id="subject"
                        type="text"
                        value={formData.subject}
                        onChange={(e) => handleInputChange('subject', e.target.value)}
                        placeholder="اكتب موضوع رسالتك"
                        required
                      />
                    </div>
                    
                    <div>
                      <Label htmlFor="message">تفاصيل الرسالة *</Label>
                      <Textarea
                        id="message"
                        value={formData.message}
                        onChange={(e) => handleInputChange('message', e.target.value)}
                        placeholder="اكتب رسالتك هنا..."
                        rows={5}
                        required
                      />
                    </div>
                    
                    <Button 
                      type="submit" 
                      className="w-full"
                      disabled={isSubmitting}
                    >
                      {isSubmitting ? (
                        <>
                          <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                          جاري الإرسال...
                        </>
                      ) : (
                        <>
                          <Send className="w-4 h-4 mr-2" />
                          إرسال الرسالة
                        </>
                      )}
                    </Button>
                  </form>
                </CardContent>
              ) : (
                <CardContent className="text-center py-8">
                  <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Send className="w-8 h-8 text-green-600" />
                  </div>
                  <Button 
                    onClick={() => setIsSubmitted(false)}
                    variant="outline"
                  >
                    إرسال رسالة أخرى
                  </Button>
                </CardContent>
              )}
            </Card>
          </div>

          {/* Contact Information & FAQ */}
          <div className="space-y-8">
            {/* Contact Info */}
            <Card>
              <CardHeader>
                <h2>معلومات التواصل</h2>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {contactInfo.map((item, index) => {
                    const Icon = item.icon;
                    return (
                      <div key={index} className="flex gap-4">
                        <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center shrink-0">
                          <Icon className="w-6 h-6 text-primary" />
                        </div>
                        <div>
                          <h4 className="font-medium mb-1">{item.title}</h4>
                          {item.details.map((detail, idx) => (
                            <p key={idx} className="text-sm">{detail}</p>
                          ))}
                          <p className="text-xs text-muted-foreground mt-1">{item.description}</p>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>

            {/* FAQ */}
            <Card>
              <CardHeader>
                <h2 className="flex items-center gap-2">
                  <HelpCircle className="w-5 h-5" />
                  الأسئلة الشائعة
                </h2>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {faqItems.map((item, index) => (
                    <div key={index} className="border-b pb-4 last:border-b-0">
                      <h4 className="font-medium mb-2">{item.question}</h4>
                      <p className="text-sm text-muted-foreground">{item.answer}</p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <Card>
              <CardHeader>
                <h3 className="flex items-center gap-2">
                  <Users className="w-5 h-5" />
                  روابط سريعة
                </h3>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <Button 
                    variant="outline" 
                    className="w-full justify-start"
                    onClick={() => onNavigate('centers')}
                  >
                    <MapPin className="w-4 h-4 mr-2" />
                    تصفح المراكز القرآنية
                  </Button>
                  
                  <Button 
                    variant="outline" 
                    className="w-full justify-start"
                    onClick={() => onNavigate('courses')}
                  >
                    <Users className="w-4 h-4 mr-2" />
                    استكشف الدورات المتاحة
                  </Button>
                  
                  <Button 
                    variant="outline" 
                    className="w-full justify-start"
                    onClick={() => onNavigate('home')}
                  >
                    <HelpCircle className="w-4 h-4 mr-2" />
                    العودة للصفحة الرئيسية
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}