import React, { useState, useMemo } from 'react';
import { quranicCenters, QuranicCenter } from '../data/centers';
import { CenterCard } from '../components/CenterCard';
import { CenterDetails } from '../components/CenterDetails';
import { SearchAndFilter } from '../components/SearchAndFilter';
import { Badge } from '../components/ui/badge';
import { PageName } from '../types/navigation';
import { BookOpen, MapPin, Users, Award } from 'lucide-react';

interface CentersPageProps {
  onNavigate: (page: PageName, centerId?: string) => void;
}

export function CentersPage({ onNavigate }: CentersPageProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCity, setSelectedCity] = useState('all');
  const [selectedLevel, setSelectedLevel] = useState('all');
  const [selectedCenter, setSelectedCenter] = useState<QuranicCenter | null>(null);
  const [isDetailsOpen, setIsDetailsOpen] = useState(false);

  // Get unique cities
  const cities = useMemo(() => {
    return Array.from(new Set(quranicCenters.map(center => center.city))).sort();
  }, []);

  // Filter centers based on search and filters
  const filteredCenters = useMemo(() => {
    return quranicCenters.filter(center => {
      const matchesSearch = searchTerm === '' || 
        center.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        center.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
        center.courses.some(course => 
          course.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
          course.description.toLowerCase().includes(searchTerm.toLowerCase())
        );

      const matchesCity = selectedCity === 'all' || center.city === selectedCity;
      
      const matchesLevel = selectedLevel === 'all' || 
        center.courses.some(course => course.level === selectedLevel);

      return matchesSearch && matchesCity && matchesLevel;
    });
  }, [searchTerm, selectedCity, selectedLevel]);

  const handleViewDetails = (center: QuranicCenter) => {
    setSelectedCenter(center);
    setIsDetailsOpen(true);
  };

  const handleCloseDetails = () => {
    setIsDetailsOpen(false);
    setSelectedCenter(null);
  };

  const clearFilters = () => {
    setSearchTerm('');
    setSelectedCity('all');
    setSelectedLevel('all');
  };

  const hasActiveFilters = searchTerm !== '' || selectedCity !== 'all' || selectedLevel !== 'all';

  // Calculate statistics
  const stats = useMemo(() => {
    const totalCenters = quranicCenters.length;
    const totalCourses = quranicCenters.reduce((sum, center) => sum + center.courses.length, 0);
    const totalCities = cities.length;
    const averageRating = quranicCenters.reduce((sum, center) => sum + center.rating, 0) / totalCenters;

    return { totalCenters, totalCourses, totalCities, averageRating };
  }, [cities.length]);

  return (
    <div className="min-h-screen bg-background">
      {/* Page Header */}
      <section className="bg-primary text-primary-foreground py-12">
        <div className="container mx-auto px-4">
          <div className="text-center space-y-4">
            <h1 className="text-4xl">المراكز القرآنية</h1>
            <p className="text-lg text-primary-foreground/90 max-w-2xl mx-auto">
              استكشف أفضل المراكز القرآنية في المملكة العربية السعودية
            </p>
            
            {/* Statistics */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-8 max-w-4xl mx-auto">
              <div className="bg-primary-foreground/10 rounded-lg p-4">
                <div className="flex items-center justify-center gap-2 mb-2">
                  <MapPin className="w-5 h-5" />
                  <span className="text-2xl font-bold">{stats.totalCenters}</span>
                </div>
                <p className="text-sm text-primary-foreground/80">مركز قرآني</p>
              </div>
              
              <div className="bg-primary-foreground/10 rounded-lg p-4">
                <div className="flex items-center justify-center gap-2 mb-2">
                  <BookOpen className="w-5 h-5" />
                  <span className="text-2xl font-bold">{stats.totalCourses}</span>
                </div>
                <p className="text-sm text-primary-foreground/80">دورة متاحة</p>
              </div>
              
              <div className="bg-primary-foreground/10 rounded-lg p-4">
                <div className="flex items-center justify-center gap-2 mb-2">
                  <Users className="w-5 h-5" />
                  <span className="text-2xl font-bold">{stats.totalCities}</span>
                </div>
                <p className="text-sm text-primary-foreground/80">مدينة</p>
              </div>
              
              <div className="bg-primary-foreground/10 rounded-lg p-4">
                <div className="flex items-center justify-center gap-2 mb-2">
                  <Award className="w-5 h-5" />
                  <span className="text-2xl font-bold">{stats.averageRating.toFixed(1)}</span>
                </div>
                <p className="text-sm text-primary-foreground/80">متوسط التقييم</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        {/* Search and Filter Section */}
        <div className="mb-8">
          <SearchAndFilter
            searchTerm={searchTerm}
            onSearchChange={setSearchTerm}
            selectedCity={selectedCity}
            onCityChange={setSelectedCity}
            selectedLevel={selectedLevel}
            onLevelChange={setSelectedLevel}
            cities={cities}
            onClearFilters={clearFilters}
            hasActiveFilters={hasActiveFilters}
          />
        </div>

        {/* Results Summary */}
        <div className="mb-6 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <h2>المراكز المتاحة</h2>
            <Badge variant="secondary">
              {filteredCenters.length} من {quranicCenters.length}
            </Badge>
          </div>
          
          {filteredCenters.length === 0 && hasActiveFilters && (
            <Badge variant="destructive">
              لا توجد نتائج للبحث الحالي
            </Badge>
          )}
        </div>

        {/* Centers Grid */}
        {filteredCenters.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredCenters.map((center) => (
              <CenterCard
                key={center.id}
                center={center}
                onViewDetails={handleViewDetails}
              />
            ))}
          </div>
        ) : (
          <div className="text-center py-12">
            <BookOpen className="w-16 h-16 mx-auto text-muted-foreground mb-4" />
            <h3 className="text-xl mb-2">لا توجد مراكز</h3>
            <p className="text-muted-foreground mb-4">
              {hasActiveFilters 
                ? 'لم نتمكن من العثور على مراكز تطابق البحث أو الفلاتر المحددة'
                : 'لا توجد مراكز قرآنية متاحة حالياً'
              }
            </p>
            {hasActiveFilters && (
              <button
                onClick={clearFilters}
                className="text-primary hover:underline"
              >
                مسح جميع الفلاتر
              </button>
            )}
          </div>
        )}
      </main>

      {/* Center Details Modal */}
      <CenterDetails
        center={selectedCenter}
        isOpen={isDetailsOpen}
        onClose={handleCloseDetails}
      />
    </div>
  );
}