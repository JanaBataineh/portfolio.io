import React, { useState, useMemo } from 'react';
import { quranicCenters, Course } from '../data/centers';
import { Card, CardContent, CardHeader } from '../components/ui/card';
import { Badge } from '../components/ui/badge';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { PageName } from '../types/navigation';
import { BookOpen, Clock, User, MapPin, DollarSign, Search, Filter, X, GraduationCap } from 'lucide-react';

interface CoursesPageProps {
  onNavigate: (page: PageName) => void;
}

interface CourseWithCenter extends Course {
  centerName: string;
  centerCity: string;
  centerRating: number;
  centerId: string;
}

export function CoursesPage({ onNavigate }: CoursesPageProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCity, setSelectedCity] = useState('all');
  const [selectedLevel, setSelectedLevel] = useState('all');
  const [sortBy, setSortBy] = useState('name');

  // Flatten all courses with center information
  const allCourses: CourseWithCenter[] = useMemo(() => {
    return quranicCenters.flatMap(center =>
      center.courses.map(course => ({
        ...course,
        centerName: center.name,
        centerCity: center.city,
        centerRating: center.rating,
        centerId: center.id
      }))
    );
  }, []);

  // Get unique cities
  const cities = useMemo(() => {
    return Array.from(new Set(quranicCenters.map(center => center.city))).sort();
  }, []);

  // Filter and sort courses
  const filteredCourses = useMemo(() => {
    let filtered = allCourses.filter(course => {
      const matchesSearch = searchTerm === '' || 
        course.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        course.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
        course.instructor.toLowerCase().includes(searchTerm.toLowerCase()) ||
        course.centerName.toLowerCase().includes(searchTerm.toLowerCase());

      const matchesCity = selectedCity === 'all' || course.centerCity === selectedCity;
      const matchesLevel = selectedLevel === 'all' || course.level === selectedLevel;

      return matchesSearch && matchesCity && matchesLevel;
    });

    // Sort courses
    switch (sortBy) {
      case 'price-low':
        filtered.sort((a, b) => a.price - b.price);
        break;
      case 'price-high':
        filtered.sort((a, b) => b.price - a.price);
        break;
      case 'rating':
        filtered.sort((a, b) => b.centerRating - a.centerRating);
        break;
      case 'name':
      default:
        filtered.sort((a, b) => a.name.localeCompare(b.name, 'ar'));
        break;
    }

    return filtered;
  }, [allCourses, searchTerm, selectedCity, selectedLevel, sortBy]);

  const clearFilters = () => {
    setSearchTerm('');
    setSelectedCity('all');
    setSelectedLevel('all');
    setSortBy('name');
  };

  const hasActiveFilters = searchTerm !== '' || selectedCity !== 'all' || selectedLevel !== 'all';

  const getLevelColor = (level: Course['level']) => {
    switch (level) {
      case 'مبتدئ': return 'bg-green-100 text-green-800';
      case 'متوسط': return 'bg-yellow-100 text-yellow-800';
      case 'متقدم': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  // Calculate statistics
  const stats = useMemo(() => {
    const totalCourses = allCourses.length;
    const averagePrice = allCourses.reduce((sum, course) => sum + course.price, 0) / totalCourses;
    const levelCounts = allCourses.reduce((acc, course) => {
      acc[course.level] = (acc[course.level] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    return { totalCourses, averagePrice, levelCounts };
  }, [allCourses]);

  return (
    <div className="min-h-screen bg-background">
      {/* Page Header */}
      <section className="bg-primary text-primary-foreground py-12">
        <div className="container mx-auto px-4">
          <div className="text-center space-y-4">
            <div className="flex justify-center items-center gap-3 mb-4">
              <GraduationCap className="w-8 h-8" />
              <h1 className="text-4xl">الدورات المتاحة</h1>
            </div>
            <p className="text-lg text-primary-foreground/90 max-w-2xl mx-auto">
              اكتشف مجموعة واسعة من الدورات القرآنية المتاحة في مختلف المراكز
            </p>
            
            {/* Statistics */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mt-8 max-w-4xl mx-auto">
              <div className="bg-primary-foreground/10 rounded-lg p-4">
                <div className="flex items-center justify-center gap-2 mb-2">
                  <BookOpen className="w-5 h-5" />
                  <span className="text-2xl font-bold">{stats.totalCourses}</span>
                </div>
                <p className="text-sm text-primary-foreground/80">دورة متاحة</p>
              </div>
              
              <div className="bg-primary-foreground/10 rounded-lg p-4">
                <div className="flex items-center justify-center gap-2 mb-2">
                  <DollarSign className="w-5 h-5" />
                  <span className="text-2xl font-bold">{Math.round(stats.averagePrice)}</span>
                </div>
                <p className="text-sm text-primary-foreground/80">متوسط السعر (ريال)</p>
              </div>
              
              <div className="bg-primary-foreground/10 rounded-lg p-4">
                <div className="flex items-center justify-center gap-2 mb-2">
                  <GraduationCap className="w-5 h-5" />
                  <span className="text-2xl font-bold">{stats.levelCounts['مبتدئ'] || 0}</span>
                </div>
                <p className="text-sm text-primary-foreground/80">دورة للمبتدئين</p>
              </div>
              
              <div className="bg-primary-foreground/10 rounded-lg p-4">
                <div className="flex items-center justify-center gap-2 mb-2">
                  <User className="w-5 h-5" />
                  <span className="text-2xl font-bold">{stats.levelCounts['متقدم'] || 0}</span>
                </div>
                <p className="text-sm text-primary-foreground/80">دورة متقدمة</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        {/* Search and Filter Section */}
        <div className="space-y-4 mb-8">
          {/* Search Bar */}
          <div className="relative">
            <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
            <Input
              type="text"
              placeholder="ابحث عن الدورات أو المعلمين أو المراكز..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pr-10"
            />
          </div>
          
          {/* Filters */}
          <div className="flex flex-wrap items-center gap-3">
            <div className="flex items-center gap-2">
              <Filter className="w-4 h-4 text-muted-foreground" />
              <span className="text-sm font-medium">التصفية والترتيب:</span>
            </div>
            
            <Select value={selectedCity} onValueChange={setSelectedCity}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="اختر المدينة" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">جميع المدن</SelectItem>
                {cities.map((city) => (
                  <SelectItem key={city} value={city}>{city}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            
            <Select value={selectedLevel} onValueChange={setSelectedLevel}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="مستوى الدورة" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">جميع المستويات</SelectItem>
                <SelectItem value="مبتدئ">مبتدئ</SelectItem>
                <SelectItem value="متوسط">متوسط</SelectItem>
                <SelectItem value="متقدم">متقدم</SelectItem>
              </SelectContent>
            </Select>
            
            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="ترتيب حسب" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="name">الاسم</SelectItem>
                <SelectItem value="price-low">السعر (من الأقل)</SelectItem>
                <SelectItem value="price-high">السعر (من الأعلى)</SelectItem>
                <SelectItem value="rating">تقييم المركز</SelectItem>
              </SelectContent>
            </Select>
            
            {hasActiveFilters && (
              <Button
                variant="outline"
                size="sm"
                onClick={clearFilters}
                className="flex items-center gap-2"
              >
                <X className="w-4 h-4" />
                مسح الفلاتر
              </Button>
            )}
          </div>
          
          {/* Active Filters Display */}
          {hasActiveFilters && (
            <div className="flex flex-wrap items-center gap-2 pt-2">
              <span className="text-sm text-muted-foreground">الفلاتر النشطة:</span>
              {selectedCity !== 'all' && (
                <Badge variant="secondary" className="flex items-center gap-1">
                  {selectedCity}
                  <X 
                    className="w-3 h-3 cursor-pointer" 
                    onClick={() => setSelectedCity('all')}
                  />
                </Badge>
              )}
              {selectedLevel !== 'all' && (
                <Badge variant="secondary" className="flex items-center gap-1">
                  {selectedLevel}
                  <X 
                    className="w-3 h-3 cursor-pointer" 
                    onClick={() => setSelectedLevel('all')}
                  />
                </Badge>
              )}
            </div>
          )}
        </div>

        {/* Results Summary */}
        <div className="mb-6 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <h2>الدورات المتاحة</h2>
            <Badge variant="secondary">
              {filteredCourses.length} من {allCourses.length}
            </Badge>
          </div>
          
          {filteredCourses.length === 0 && hasActiveFilters && (
            <Badge variant="destructive">
              لا توجد نتائج للبحث الحالي
            </Badge>
          )}
        </div>

        {/* Courses Grid */}
        {filteredCourses.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {filteredCourses.map((course) => (
              <Card key={`${course.centerId}-${course.id}`} className="hover:shadow-lg transition-shadow duration-200">
                <CardHeader className="pb-3">
                  <div className="flex justify-between items-start gap-3">
                    <h3 className="line-clamp-2">{course.name}</h3>
                    <Badge className={`shrink-0 ${getLevelColor(course.level)}`}>
                      {course.level}
                    </Badge>
                  </div>
                  <p className="text-muted-foreground line-clamp-2">{course.description}</p>
                </CardHeader>
                
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 gap-3 text-sm">
                    <div className="flex items-center gap-2">
                      <MapPin className="w-4 h-4 text-muted-foreground" />
                      <span>{course.centerName} - {course.centerCity}</span>
                    </div>
                    
                    <div className="flex items-center gap-2">
                      <User className="w-4 h-4 text-muted-foreground" />
                      <span>{course.instructor}</span>
                    </div>
                    
                    <div className="flex items-center gap-2">
                      <Clock className="w-4 h-4 text-muted-foreground" />
                      <span>{course.duration}</span>
                    </div>
                    
                    <div className="flex items-center gap-2">
                      <DollarSign className="w-4 h-4 text-muted-foreground" />
                      <span className="font-medium">{course.price} ريال سعودي</span>
                    </div>
                  </div>
                  
                  <div className="border-t pt-3">
                    <p className="text-sm text-muted-foreground mb-2">الجدول الزمني:</p>
                    <p className="text-sm">{course.schedule}</p>
                  </div>
                  
                  <div className="flex gap-2">
                    <Button size="sm" className="flex-1">
                      التسجيل في الدورة
                    </Button>
                    <Button 
                      size="sm" 
                      variant="outline"
                      onClick={() => onNavigate('centers')}
                      className="flex-1"
                    >
                      عرض المركز
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <div className="text-center py-12">
            <GraduationCap className="w-16 h-16 mx-auto text-muted-foreground mb-4" />
            <h3 className="text-xl mb-2">لا توجد دورات</h3>
            <p className="text-muted-foreground mb-4">
              {hasActiveFilters 
                ? 'لم نتمكن من العثور على دورات تطابق البحث أو الفلاتر المحددة'
                : 'لا توجد دورات متاحة حالياً'
              }
            </p>
            {hasActiveFilters && (
              <button
                onClick={clearFilters}
                className="text-primary hover:underline"
              >
                مسح جميع الفلاتر
              </button>
            )}
          </div>
        )}
      </main>
    </div>
  );
}