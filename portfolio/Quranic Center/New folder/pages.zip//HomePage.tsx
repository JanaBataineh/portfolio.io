import React from 'react';
import { Button } from '../components/ui/button';
import { Card, CardContent } from '../components/ui/card';
import { ImageWithFallback } from '../components/figma/ImageWithFallback';
import { PageName } from '../types/navigation';
import { quranicCenters } from '../data/centers';
import { BookOpen, MapPin, Users, Award, ArrowLeft, Star, Clock, GraduationCap } from 'lucide-react';

interface HomePageProps {
  onNavigate: (page: PageName) => void;
}

export function HomePage({ onNavigate }: HomePageProps) {
  // Calculate statistics
  const stats = {
    totalCenters: quranicCenters.length,
    totalCourses: quranicCenters.reduce((sum, center) => sum + center.courses.length, 0),
    totalCities: Array.from(new Set(quranicCenters.map(center => center.city))).length,
    averageRating: quranicCenters.reduce((sum, center) => sum + center.rating, 0) / quranicCenters.length
  };

  // Get featured centers (top rated)
  const featuredCenters = quranicCenters
    .sort((a, b) => b.rating - a.rating)
    .slice(0, 3);

  // Get recent courses
  const recentCourses = quranicCenters
    .flatMap(center => center.courses.map(course => ({ ...course, centerName: center.name, centerCity: center.city })))
    .slice(0, 4);

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="bg-gradient-to-b from-primary to-primary/90 text-primary-foreground">
        <div className="container mx-auto px-4 py-20">
          <div className="max-w-4xl mx-auto text-center space-y-6">
            <div className="flex justify-center items-center gap-3 mb-6">
              <BookOpen className="w-12 h-12" />
              <h1 className="text-5xl">دليل المراكز القرآنية</h1>
            </div>
            
            <p className="text-xl text-primary-foreground/90 max-w-2xl mx-auto leading-relaxed">
              منصتك الشاملة للعثور على أفضل المراكز القرآنية في المملكة العربية السعودية والدورات المتاحة فيها. 
              اكتشف مراكز التحفيظ المعتمدة والمعلمين المؤهلين.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center mt-8">
              <Button 
                size="lg" 
                variant="secondary"
                onClick={() => onNavigate('centers')}
                className="text-lg px-8 py-3"
              >
                استكشف المراكز
                <ArrowLeft className="w-5 h-5 mr-2" />
              </Button>
              
              <Button 
                size="lg" 
                variant="outline"
                onClick={() => onNavigate('courses')}
                className="text-lg px-8 py-3 border-primary-foreground/20 text-primary-foreground hover:bg-primary-foreground/10"
              >
                تصفح الدورات
                <GraduationCap className="w-5 h-5 mr-2" />
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Statistics Section */}
      <section className="py-16 bg-muted/50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl mb-4">إحصائيات المنصة</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              نحن نقدم خدماتنا عبر شبكة واسعة من المراكز المعتمدة والدورات المتنوعة
            </p>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 max-w-4xl mx-auto">
            <Card className="text-center">
              <CardContent className="p-6">
                <div className="flex items-center justify-center gap-2 mb-3">
                  <MapPin className="w-8 h-8 text-primary" />
                  <span className="text-3xl font-bold text-primary">{stats.totalCenters}</span>
                </div>
                <p className="text-muted-foreground">مركز قرآني</p>
              </CardContent>
            </Card>
            
            <Card className="text-center">
              <CardContent className="p-6">
                <div className="flex items-center justify-center gap-2 mb-3">
                  <BookOpen className="w-8 h-8 text-primary" />
                  <span className="text-3xl font-bold text-primary">{stats.totalCourses}</span>
                </div>
                <p className="text-muted-foreground">دورة متاحة</p>
              </CardContent>
            </Card>
            
            <Card className="text-center">
              <CardContent className="p-6">
                <div className="flex items-center justify-center gap-2 mb-3">
                  <Users className="w-8 h-8 text-primary" />
                  <span className="text-3xl font-bold text-primary">{stats.totalCities}</span>
                </div>
                <p className="text-muted-foreground">مدينة</p>
              </CardContent>
            </Card>
            
            <Card className="text-center">
              <CardContent className="p-6">
                <div className="flex items-center justify-center gap-2 mb-3">
                  <Award className="w-8 h-8 text-primary" />
                  <span className="text-3xl font-bold text-primary">{stats.averageRating.toFixed(1)}</span>
                </div>
                <p className="text-muted-foreground">متوسط التقييم</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Featured Centers */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl mb-4">المراكز المميزة</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              اكتشف أفضل المراكز القرآنية حسب تقييمات الطلاب والجودة المقدمة
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-6xl mx-auto">
            {featuredCenters.map((center) => (
              <Card key={center.id} className="overflow-hidden hover:shadow-lg transition-shadow duration-200">
                <div className="relative">
                  <ImageWithFallback
                    src={center.image}
                    alt={center.name}
                    className="w-full h-48 object-cover"
                  />
                  <div className="absolute top-3 right-3 bg-white/90 backdrop-blur-sm rounded-full px-3 py-1 flex items-center gap-1">
                    <Star className="w-4 h-4 text-yellow-500 fill-current" />
                    <span className="font-medium">{center.rating}</span>
                  </div>
                </div>
                
                <CardContent className="p-6">
                  <h3 className="mb-2 line-clamp-2">{center.name}</h3>
                  <p className="text-muted-foreground text-sm mb-4 line-clamp-2">
                    {center.description}
                  </p>
                  
                  <div className="flex items-center gap-2 text-sm text-muted-foreground mb-4">
                    <MapPin className="w-4 h-4" />
                    <span>{center.city}</span>
                  </div>
                  
                  <Button 
                    onClick={() => onNavigate('centers')}
                    className="w-full"
                    size="sm"
                  >
                    عرض التفاصيل
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
          
          <div className="text-center mt-8">
            <Button 
              variant="outline" 
              size="lg"
              onClick={() => onNavigate('centers')}
            >
              عرض جميع المراكز
              <ArrowLeft className="w-4 h-4 mr-2" />
            </Button>
          </div>
        </div>
      </section>

      {/* Recent Courses */}
      <section className="py-16 bg-muted/50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl mb-4">أحدث الدورات</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              تصفح أحدث الدورات القرآنية المتاحة في مختلف المراكز
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-4xl mx-auto">
            {recentCourses.map((course) => (
              <Card key={course.id} className="hover:shadow-md transition-shadow duration-200">
                <CardContent className="p-6">
                  <div className="flex justify-between items-start mb-3">
                    <h4 className="line-clamp-2">{course.name}</h4>
                    <span className={`text-xs px-2 py-1 rounded-full ${
                      course.level === 'مبتدئ' ? 'bg-green-100 text-green-800' :
                      course.level === 'متوسط' ? 'bg-yellow-100 text-yellow-800' :
                      'bg-red-100 text-red-800'
                    }`}>
                      {course.level}
                    </span>
                  </div>
                  
                  <p className="text-sm text-muted-foreground mb-4 line-clamp-2">
                    {course.description}
                  </p>
                  
                  <div className="space-y-2 text-sm">
                    <div className="flex items-center gap-2">
                      <MapPin className="w-4 h-4 text-muted-foreground" />
                      <span>{course.centerName} - {course.centerCity}</span>
                    </div>
                    
                    <div className="flex items-center gap-2">
                      <Clock className="w-4 h-4 text-muted-foreground" />
                      <span>{course.duration}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
          
          <div className="text-center mt-8">
            <Button 
              variant="outline" 
              size="lg"
              onClick={() => onNavigate('courses')}
            >
              عرض جميع الدورات
              <ArrowLeft className="w-4 h-4 mr-2" />
            </Button>
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-16 bg-primary text-primary-foreground">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center space-y-6">
            <h2 className="text-3xl">ابدأ رحلتك القرآنية اليوم</h2>
            <p className="text-xl text-primary-foreground/90">
              انضم إلى آلاف الطلاب الذين اختاروا مراكزنا المعتمدة لتعلم القرآن الكريم وتحفيظه
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button 
                size="lg" 
                variant="secondary"
                onClick={() => onNavigate('centers')}
                className="text-lg px-8 py-3"
              >
                ابحث عن مركز قريب منك
              </Button>
              <Button 
                size="lg" 
                variant="outline"
                onClick={() => onNavigate('contact')}
                className="text-lg px-8 py-3 border-primary-foreground/20 text-primary-foreground hover:bg-primary-foreground/10"
              >
                اتصل بنا للاستفسار
              </Button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}