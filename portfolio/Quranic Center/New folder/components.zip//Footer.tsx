import React from 'react';
import { Button } from './ui/button';
import { PageName } from '../types/navigation';
import { BookOpen, MapPin, GraduationCap, Phone, Mail, Heart } from 'lucide-react';

interface FooterProps {
  onNavigate: (page: PageName) => void;
}

export function Footer({ onNavigate }: FooterProps) {
  const currentYear = new Date().getFullYear();

  const quickLinks = [
    { id: 'home' as PageName, label: 'الرئيسية', icon: BookOpen },
    { id: 'centers' as PageName, label: 'المراكز القرآنية', icon: MapPin },
    { id: 'courses' as PageName, label: 'الدورات المتاحة', icon: GraduationCap },
    { id: 'contact' as PageName, label: 'اتصل بنا', icon: Phone },
  ];

  return (
    <footer className="bg-muted mt-16">
      {/* Main Footer Content */}
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* About Section */}
          <div>
            <div className="flex items-center gap-3 mb-4">
              <BookOpen className="w-8 h-8 text-primary" />
              <span className="font-bold text-lg">دليل المراكز القرآنية</span>
            </div>
            <p className="text-muted-foreground mb-4 leading-relaxed">
              منصة شاملة للعثور على أفضل المراكز القرآنية والدورات المتاحة فيها في المملكة العربية السعودية. 
              نساعدك في العثور على المركز المناسب لتعلم القرآن الكريم وتحفيظه.
            </p>
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <span>صُنع بـ</span>
              <Heart className="w-4 h-4 text-red-500 fill-current" />
              <span>في المملكة العربية السعودية</span>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="font-medium mb-4">روابط سريعة</h3>
            <div className="space-y-2">
              {quickLinks.map((link) => {
                const Icon = link.icon;
                return (
                  <Button
                    key={link.id}
                    variant="ghost"
                    size="sm"
                    onClick={() => onNavigate(link.id)}
                    className="w-full justify-start p-2 h-auto text-muted-foreground hover:text-foreground"
                  >
                    <Icon className="w-4 h-4 mr-2" />
                    {link.label}
                  </Button>
                );
              })}
            </div>
          </div>

          {/* Services */}
          <div>
            <h3 className="font-medium mb-4">خدماتنا</h3>
            <div className="space-y-2 text-sm text-muted-foreground">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-primary rounded-full"></div>
                <span>دليل المراكز القرآنية</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-primary rounded-full"></div>
                <span>عرض الدورات المتاحة</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-primary rounded-full"></div>
                <span>البحث والتصفية المتقدمة</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-primary rounded-full"></div>
                <span>معلومات تفصيلية عن المراكز</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-primary rounded-full"></div>
                <span>تقييمات المستخدمين</span>
              </div>
            </div>
          </div>

          {/* Contact Info */}
          <div>
            <h3 className="font-medium mb-4">تواصل معنا</h3>
            <div className="space-y-3 text-sm text-muted-foreground">
              <div className="flex items-center gap-2">
                <Phone className="w-4 h-4" />
                <span>+966 11 123 4567</span>
              </div>
              <div className="flex items-center gap-2">
                <Mail className="w-4 h-4" />
                <span>info@quran-centers.sa</span>
              </div>
              <div className="flex items-center gap-2">
                <MapPin className="w-4 h-4" />
                <span>الرياض، المملكة العربية السعودية</span>
              </div>
            </div>
            
            <div className="mt-4">
              <Button 
                onClick={() => onNavigate('contact')}
                size="sm"
                className="w-full"
              >
                <Mail className="w-4 h-4 mr-2" />
                تواصل معنا
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Footer */}
      <div className="border-t bg-muted/50">
        <div className="container mx-auto px-4 py-6">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="text-sm text-muted-foreground text-center md:text-right">
              © {currentYear} دليل المراكز القرآنية. جميع الحقوق محفوظة.
            </div>
            
            <div className="flex items-center gap-4 text-sm text-muted-foreground">
              <button className="hover:text-foreground transition-colors">
                سياسة الخصوصية
              </button>
              <span>|</span>
              <button className="hover:text-foreground transition-colors">
                شروط الاستخدام
              </button>
              <span>|</span>
              <button className="hover:text-foreground transition-colors">
                المساعدة
              </button>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}