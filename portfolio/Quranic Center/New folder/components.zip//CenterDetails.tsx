import React from 'react';
import { QuranicCenter, Course } from '../data/centers';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { MapPin, Phone, Mail, Globe, Star, Calendar, Clock, User, BookOpen, DollarSign } from 'lucide-react';

interface CenterDetailsProps {
  center: QuranicCenter | null;
  isOpen: boolean;
  onClose: () => void;
}

function CourseCard({ course }: { course: Course }) {
  const getLevelColor = (level: Course['level']) => {
    switch (level) {
      case 'مبتدئ': return 'bg-green-100 text-green-800';
      case 'متوسط': return 'bg-yellow-100 text-yellow-800';
      case 'متقدم': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="border rounded-lg p-4 space-y-3 hover:bg-muted/50 transition-colors">
      <div className="flex justify-between items-start gap-3">
        <h4 className="line-clamp-2">{course.name}</h4>
        <Badge className={`shrink-0 ${getLevelColor(course.level)}`}>
          {course.level}
        </Badge>
      </div>
      
      <p className="text-sm text-muted-foreground line-clamp-2">{course.description}</p>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-sm">
        <div className="flex items-center gap-2">
          <Clock className="w-4 h-4 text-muted-foreground" />
          <span>{course.duration}</span>
        </div>
        
        <div className="flex items-center gap-2">
          <User className="w-4 h-4 text-muted-foreground" />
          <span>{course.instructor}</span>
        </div>
        
        <div className="flex items-center gap-2 md:col-span-2">
          <Calendar className="w-4 h-4 text-muted-foreground" />
          <span>{course.schedule}</span>
        </div>
        
        <div className="flex items-center gap-2 md:col-span-2">
          <DollarSign className="w-4 h-4 text-muted-foreground" />
          <span className="font-medium">{course.price} ريال سعودي</span>
        </div>
      </div>
      
      <Button size="sm" className="w-full">
        التسجيل في الدورة
      </Button>
    </div>
  );
}

export function CenterDetails({ center, isOpen, onClose }: CenterDetailsProps) {
  if (!center) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-right">{center.name}</DialogTitle>
        </DialogHeader>
        
        <div className="space-y-6">
          <div className="relative">
            <ImageWithFallback
              src={center.image}
              alt={center.name}
              className="w-full h-64 object-cover rounded-lg"
            />
            <div className="absolute top-3 right-3 bg-white/90 backdrop-blur-sm rounded-full px-3 py-1 flex items-center gap-1">
              <Star className="w-4 h-4 text-yellow-500 fill-current" />
              <span className="font-medium">{center.rating}</span>
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <h3>معلومات المركز</h3>
              <p className="text-muted-foreground">{center.description}</p>
              
              <div className="space-y-3">
                <div className="flex items-center gap-3">
                  <MapPin className="w-5 h-5 text-muted-foreground" />
                  <div>
                    <p>{center.address}</p>
                    <p className="text-sm text-muted-foreground">{center.city}</p>
                  </div>
                </div>
                
                <div className="flex items-center gap-3">
                  <Phone className="w-5 h-5 text-muted-foreground" />
                  <span>{center.phone}</span>
                </div>
                
                <div className="flex items-center gap-3">
                  <Mail className="w-5 h-5 text-muted-foreground" />
                  <span>{center.email}</span>
                </div>
                
                {center.website && (
                  <div className="flex items-center gap-3">
                    <Globe className="w-5 h-5 text-muted-foreground" />
                    <span>{center.website}</span>
                  </div>
                )}
                
                <div className="flex items-center gap-3">
                  <Calendar className="w-5 h-5 text-muted-foreground" />
                  <span>تأسس عام {center.established}</span>
                </div>
              </div>
            </div>
            
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3>الدورات المتاحة</h3>
                <Badge variant="secondary">
                  {center.courses.length} دورة
                </Badge>
              </div>
              
              <div className="space-y-3 max-h-96 overflow-y-auto">
                {center.courses.map((course) => (
                  <CourseCard key={course.id} course={course} />
                ))}
              </div>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}