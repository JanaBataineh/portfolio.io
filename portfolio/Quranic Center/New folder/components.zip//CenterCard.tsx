import React from 'react';
import { QuranicCenter } from '../data/centers';
import { Card, CardContent, CardHeader } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { MapPin, Phone, Mail, Globe, Star, Calendar, Users } from 'lucide-react';

interface CenterCardProps {
  center: QuranicCenter;
  onViewDetails: (center: QuranicCenter) => void;
}

export function CenterCard({ center, onViewDetails }: CenterCardProps) {
  return (
    <Card className="overflow-hidden hover:shadow-lg transition-shadow duration-200">
      <div className="relative">
        <ImageWithFallback
          src={center.image}
          alt={center.name}
          className="w-full h-48 object-cover"
        />
        <div className="absolute top-3 right-3 bg-white/90 backdrop-blur-sm rounded-full px-2 py-1 flex items-center gap-1">
          <Star className="w-4 h-4 text-yellow-500 fill-current" />
          <span className="font-medium">{center.rating}</span>
        </div>
      </div>
      
      <CardHeader className="pb-3">
        <div className="flex justify-between items-start gap-3">
          <h3 className="line-clamp-2">{center.name}</h3>
          <Badge variant="secondary" className="shrink-0">
            {center.courses.length} دورة
          </Badge>
        </div>
        <p className="text-muted-foreground line-clamp-2">{center.description}</p>
      </CardHeader>
      
      <CardContent className="space-y-3">
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <MapPin className="w-4 h-4 shrink-0" />
          <span className="line-clamp-1">{center.address}, {center.city}</span>
        </div>
        
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <Phone className="w-4 h-4 shrink-0" />
          <span>{center.phone}</span>
        </div>
        
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <Calendar className="w-4 h-4 shrink-0" />
          <span>تأسس عام {center.established}</span>
        </div>
        
        <div className="flex flex-wrap gap-2 mt-3">
          {center.courses.slice(0, 2).map((course) => (
            <Badge key={course.id} variant="outline" className="text-xs">
              {course.name}
            </Badge>
          ))}
          {center.courses.length > 2 && (
            <Badge variant="outline" className="text-xs">
              +{center.courses.length - 2} المزيد
            </Badge>
          )}
        </div>
        
        <Button 
          onClick={() => onViewDetails(center)}
          className="w-full mt-4"
        >
          عرض التفاصيل والدورات
        </Button>
      </CardContent>
    </Card>
  );
}