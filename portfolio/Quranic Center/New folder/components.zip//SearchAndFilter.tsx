import React from 'react';
import { Input } from './ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Search, Filter, X } from 'lucide-react';

interface SearchAndFilterProps {
  searchTerm: string;
  onSearchChange: (value: string) => void;
  selectedCity: string;
  onCityChange: (value: string) => void;
  selectedLevel: string;
  onLevelChange: (value: string) => void;
  cities: string[];
  onClearFilters: () => void;
  hasActiveFilters: boolean;
}

export function SearchAndFilter({
  searchTerm,
  onSearchChange,
  selectedCity,
  onCityChange,
  selectedLevel,
  onLevelChange,
  cities,
  onClearFilters,
  hasActiveFilters
}: SearchAndFilterProps) {
  return (
    <div className="space-y-4">
      {/* Search Bar */}
      <div className="relative">
        <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
        <Input
          type="text"
          placeholder="ابحث عن المراكز أو الدورات..."
          value={searchTerm}
          onChange={(e) => onSearchChange(e.target.value)}
          className="pr-10"
        />
      </div>
      
      {/* Filters */}
      <div className="flex flex-wrap items-center gap-3">
        <div className="flex items-center gap-2">
          <Filter className="w-4 h-4 text-muted-foreground" />
          <span className="text-sm font-medium">التصفية:</span>
        </div>
        
        <Select value={selectedCity} onValueChange={onCityChange}>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="اختر المدينة" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">جميع المدن</SelectItem>
            {cities.map((city) => (
              <SelectItem key={city} value={city}>{city}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        
        <Select value={selectedLevel} onValueChange={onLevelChange}>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="مستوى الدورات" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">جميع المستويات</SelectItem>
            <SelectItem value="مبتدئ">مبتدئ</SelectItem>
            <SelectItem value="متوسط">متوسط</SelectItem>
            <SelectItem value="متقدم">متقدم</SelectItem>
          </SelectContent>
        </Select>
        
        {hasActiveFilters && (
          <Button
            variant="outline"
            size="sm"
            onClick={onClearFilters}
            className="flex items-center gap-2"
          >
            <X className="w-4 h-4" />
            مسح الفلاتر
          </Button>
        )}
      </div>
      
      {/* Active Filters Display */}
      {hasActiveFilters && (
        <div className="flex flex-wrap items-center gap-2 pt-2">
          <span className="text-sm text-muted-foreground">الفلاتر النشطة:</span>
          {selectedCity !== 'all' && (
            <Badge variant="secondary" className="flex items-center gap-1">
              {selectedCity}
              <X 
                className="w-3 h-3 cursor-pointer" 
                onClick={() => onCityChange('all')}
              />
            </Badge>
          )}
          {selectedLevel !== 'all' && (
            <Badge variant="secondary" className="flex items-center gap-1">
              {selectedLevel}
              <X 
                className="w-3 h-3 cursor-pointer" 
                onClick={() => onLevelChange('all')}
              />
            </Badge>
          )}
        </div>
      )}
    </div>
  );
}