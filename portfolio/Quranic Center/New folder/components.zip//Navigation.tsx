import React from 'react';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { BookOpen, Home, MapPin, GraduationCap, Phone, Menu, X } from 'lucide-react';
import { PageName } from '../types/navigation';
import { quranicCenters } from '../data/centers';
import { useState } from 'react';

interface NavigationProps {
  currentPage: PageName;
  onNavigate: (page: PageName) => void;
}

export function Navigation({ currentPage, onNavigate }: NavigationProps) {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const totalCourses = quranicCenters.reduce((sum, center) => sum + center.courses.length, 0);

  const navigationItems = [
    { id: 'home' as PageName, label: 'الرئيسية', icon: Home },
    { id: 'centers' as PageName, label: 'المراكز', icon: MapPin, badge: quranicCenters.length },
    { id: 'courses' as PageName, label: 'الدورات', icon: GraduationCap, badge: totalCourses },
    { id: 'contact' as PageName, label: 'اتصل بنا', icon: Phone },
  ];

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  return (
    <nav className="bg-white border-b sticky top-0 z-50 shadow-sm">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div 
            className="flex items-center gap-3 cursor-pointer"
            onClick={() => onNavigate('home')}
          >
            <BookOpen className="w-8 h-8 text-primary" />
            <div className="hidden md:block">
              <span className="font-bold text-lg">دليل المراكز القرآنية</span>
              <p className="text-xs text-muted-foreground">اكتشف أفضل المراكز والدورات</p>
            </div>
            <span className="md:hidden font-bold">المراكز القرآنية</span>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center gap-2">
            {navigationItems.map((item) => {
              const Icon = item.icon;
              const isActive = currentPage === item.id;
              
              return (
                <Button
                  key={item.id}
                  variant={isActive ? "default" : "ghost"}
                  onClick={() => onNavigate(item.id)}
                  className="flex items-center gap-2 relative"
                >
                  <Icon className="w-4 h-4" />
                  <span>{item.label}</span>
                  {item.badge && (
                    <Badge variant="secondary" className="mr-1 text-xs">
                      {item.badge}
                    </Badge>
                  )}
                </Button>
              );
            })}
          </div>

          {/* Mobile Menu Button */}
          <Button
            variant="ghost"
            size="sm"
            className="md:hidden"
            onClick={toggleMobileMenu}
          >
            {isMobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </Button>
        </div>

        {/* Mobile Navigation */}
        {isMobileMenuOpen && (
          <div className="md:hidden border-t bg-white py-4">
            <div className="space-y-2">
              {navigationItems.map((item) => {
                const Icon = item.icon;
                const isActive = currentPage === item.id;
                
                return (
                  <Button
                    key={item.id}
                    variant={isActive ? "default" : "ghost"}
                    onClick={() => {
                      onNavigate(item.id);
                      setIsMobileMenuOpen(false);
                    }}
                    className="w-full justify-start flex items-center gap-3"
                  >
                    <Icon className="w-4 h-4" />
                    <span>{item.label}</span>
                    {item.badge && (
                      <Badge variant="secondary" className="mr-auto text-xs">
                        {item.badge}
                      </Badge>
                    )}
                  </Button>
                );
              })}
            </div>
          </div>
        )}
      </div>
    </nav>
  );
}